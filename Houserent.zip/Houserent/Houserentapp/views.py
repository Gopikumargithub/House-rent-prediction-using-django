from django.shortcuts import render
import pickle
import numpy as np
import sklearn

def home(request):
    return render(request,'index.html')
def predict(request):
    model = pickle.load(open('model.pkl', 'rb'))
    beds = request.GET.get('beds')
    bath = request.GET.get('bathrooms')
    floors = request.GET.get('floors')
    year  = request.GET.get('year')
    arr = np.array([beds,bath,floors,year])
    arr = arr.astype(np.float64)
    pred = model.predict([arr])
    return render(request,'index.html',{'result':round(pred[0][0])})

# Create your views here.
