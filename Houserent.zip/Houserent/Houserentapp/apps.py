from django.apps import AppConfig


class HouserentappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Houserentapp'
